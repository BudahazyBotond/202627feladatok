<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CalculatorController extends Controller
{
    public function result(int $a, string $op, int $b){
        if($op == "+"){
            return ["data"=>[
                "title"=>"Összeadás",
                "a"=>$a,
                "b"=>$b,
                "result"=> $a+$b
                ]
            ];
        }
        else if($op == "-"){
            return ["data"=>[
                "title"=>"Kivonás",
                "a"=>$a,
                "b"=>$b,
                "result"=> $a-$b
                ]
            ];
        }
        else if($op == "*"){
            return ["data"=>[
                "title"=>"Szorzás",
                "a"=>$a,
                "b"=>$b,
                "result"=> $a*$b
                ]
            ];
        }
        else if($op == "/"){
            if($b==0){
                abort(400);
            }
            return ["data"=>[
                "title"=>"Osztás",
                "a"=>$a,
                "b"=>$b,
                "result"=> ($a/$b)
                ]
            ];
        }
        else{
            abort(404);
        }
    }
}
