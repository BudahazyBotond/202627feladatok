<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \DateTime;
use Illuminate\Support\Facades\Date;

class CalendarController extends Controller
{
    public function today(){
        return ["data" => [
            "title"=> "Ma",
            "date"=> new DateTime("now")->format("Y-m-d"),
        ]];
    }

    public function yesterday(){
        return ["data" => [
            "title"=> "Tegnap",
            "date"=> new DateTime("now")->modify('-1 day')->format("Y-m-d"),
        ]];
    }
    public function tomorrow(){
        return ["data" => [
            "title"=> "Holnap",
            "date"=> new DateTime("now")->modify('+1 day')->format("Y-m-d"),
        ]];
    }

    protected $weekdays = [
        "hétfő","kedd","szerda","csütörtök","péntek","szombat","vasárnap"
    ];

    public function weekdayName(int $number){
        if($number >7 || $number < 1){
            return ["error" => "A hét napjához adja meg a sorszámát (1 és 7 közötti szám)"];
        }
        return ["data" => $this->weekdays[$number-1]];
    }

    public function weekdayNumber(string $name){
        $index = array_search($name, $this->weekdays);
        if($index === false){
            return ["error"=> "Ismeretlen nap!"];
        }
        return ["data"=> $this->weekdays[$index+ 1]];
    }
}
