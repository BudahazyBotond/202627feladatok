<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class QuoteController extends Controller
{
    public function index(){
        return ["data"=>$this->loadQuotes()];
    }

    public function house(){
        $quotes = $this->loadQuotes();
        return ["data"=>$quotes->firstWhere("name","=","Dr. House")];
    }

    public function modernFamily(){
        $quotes = $this->loadQuotes();
        return ["data"=>$quotes->firstWhere("name","=","Phil Dunphy")];
    }

    public function uvegtirgisCsoki(){
        $quotes = $this->loadQuotes();
        return ["data"=>$quotes->firstWhere("name","=","Csoki")];
    }

    public function uvegtirgisLali(){
        $quotes = $this->loadQuotes();
        return ["data"=>$quotes->firstWhere("name","=","Lali")];
    }

    public function HarryPotter(string $slug){
        $quotes = $this->loadQuotes();
        if($slug == "fred-es-george"){
            return ["data"=>$quotes->firstWhere("name","=","Fred és George")];
        }
        else if($slug == "hermione"){
            return ["data"=>$quotes->firstWhere("name","=","Hermione")];
        }
        else{
            abort(404);
        }
    }


    private function loadQuotes()
    {
        return collect([
            [
                "title"=>"House",
                "quote"=>"Nemcsak az emberek megalázásával lehet a gőzt kiereszteni; mondják, hogy a bowling jobb még ennél is.",
                "name"=> "Dr. House",
            ],
            [
                "title"=>"Üvegtigris",
                "quote"=>"Mennyire vagy túsz? Sörhöz odaférsz?",
                "name"=> "Csoki",
            ],
            [
                "title"=>"Üvegtigris",
                "quote"=>"Az egybubis az egy kicsit drágább, mert hát abból ki kellett vennem a többi bubit.",
                "name"=> "Lali",
            ],
            [
                "title"=>"Modern Család",
                "quote"=>"A siker mindig 1 százalék ihlet, plusz 98 százalék verejték, végül pedig 2 százalék odafigyelés.",
                "name"=> "Phil Dunphy",
            ],
            [
                "title"=>"Harry Potter",
                "quote"=>"- Mindig is tudtuk hol a határ - bólintott Fred - És csak óvatosan léptük át - tette hozzá George.",
                "name"=> "Fred és George",
            ],
            [
                "title"=>"Harry Potter",
                "quote"=>"Még egy ilyen remek ötlet, és mindhárman meghalunk, vagy akár ki is csaphatnak!",
                "name"=> "Hermione",
            ]
        ]);
    }
}
















