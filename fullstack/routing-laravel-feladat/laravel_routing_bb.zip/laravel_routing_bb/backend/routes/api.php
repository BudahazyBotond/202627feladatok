<?php

use App\Http\Controllers\CalculatorController;
use App\Http\Controllers\CarController;
use App\Http\Controllers\QuoteController;
use App\Http\Controllers\CalendarController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get("cars",
[CarController::class,"index"]) ->
name("cars.name");

Route::get("cars/{id}",
[CarController::class,"show"]) ->
name("cars.show");

Route::get("idezetek/house",
[QuoteController::class,"house"]) ->
name("quote.house");

Route::get("idezetek/modern-family",
[QuoteController::class,"modernFamily"]) ->
name("quote.modernFamily");

Route::get("idezetek/uvegtigris/csoki",
[QuoteController::class,"uvegtirgisCsoki"]) ->
name("quote.uvegtigrisCsoki");

Route::get("idezetek/uvegtigris/lali",
[QuoteController::class,"uvegtirgisLali"]) ->
name("quote.uvegtigrisLali");

Route::get("idezetek/harry-potter/{slug}",
[QuoteController::class,"harryPotter"]) ->
name("quote.harryPotter");

Route::get("naptar/ma",
[CalendarController::class,"today"]) ->
name("calendar.today");

Route::get("naptar/tegnap",
[CalendarController::class,"yesterday"]) ->
name("calendar.yesterday");

Route::get("naptar/holnap",
[CalendarController::class,"tomorrow"]) ->
name("calendar.tomorrow");

Route::get("hetnapja/{number}",
[CalendarController::class,"weekdayName"]) 
->where([
    "number" => "[0-9]+"
])
-> name("weekday.name");

Route::get("hetnapja/{name}",
[CalendarController::class,"weekdayNumber"]) 
-> name("weekday.number");

Route::get("szamologep/{a}{op}{b}",
[CalculatorController::class,"result"]) ->
where([
    'a' => '[0-9]+',
    'op' => '[+\-*/]',
    'b' => '[0-9]+' 
])-> name('calculator.result');
